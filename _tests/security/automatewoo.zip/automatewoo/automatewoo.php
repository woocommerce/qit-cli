<?php

/*
 * Plugin name: Security - Plugin A
 */

add_action( 'init', static function() {
	if ( isset( $_POST['foo'] ) ) {
		$foo = $_POST['foo'];

		echo "Unescaped output! $foo";
	}
} );