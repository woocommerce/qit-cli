<?php
echo "\nget_loaded_extensions():\n";
$loaded_extensions = get_loaded_extensions();
sort($loaded_extensions); 
echo json_encode( $loaded_extensions, JSON_PRETTY_PRINT ) . "\n";

$expected_extensions = json_decode($_GET['php_extensions']);

echo "Expecting extensions: {$_GET['php_extensions']} \n";

foreach ($expected_extensions as $ext) {
	if (!in_array($ext, $loaded_extensions)) {
		echo "\nERROR: $ext is not loaded\n";
		exit(1);
	} else {
		echo "\nOK: $ext is loaded\n";
	}
}