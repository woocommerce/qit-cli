<?php

$env = getenv();

$required_envs = [
	'QIT_ENV_ID',
	'CACHE_DIR',
];

foreach ( $required_envs as $required_env ) {
	if ( ! isset( $env[ $required_env ] ) ) {
		echo "Missing required environment variable: $required_env\n";
		die( 1 );
	}
}

if ( ! preg_match( '/^[a-z0-9]+$/i', $env['QIT_ENV_ID'] ) ) {
	echo "QIT_ENV_ID should be alphanumeric only.\n";
	die( 1 );
}

if ( ! file_exists( $env['CACHE_DIR'] ) ) {
	echo "Cache dir not found: " . $env['CACHE_DIR'] . "\n";
	die( 1 );
}

if ( ! is_writable( $env['CACHE_DIR'] ) ) {
	echo "Cache dir is not writable: " . $env['CACHE_DIR'] . "\n";
	die( 1 );
}

$default_volumes = [
	'html'            => '/var/www/html',
	'bin'             => '/qit/bin',
	$env['CACHE_DIR'] => '/qit/cache',
];

// Map mu-plugins individually instead of the whole container to avoid bringing mu-plugins in container back to host.
foreach ( new DirectoryIterator( __DIR__ . '/mu-plugins' ) as $mu_plugin ) {
	/** @var SplFileInfo $mu_plugin */
	if ( $mu_plugin->isFile() && $mu_plugin->getExtension() === 'php' ) {
		$default_volumes["mu-plugins/{$mu_plugin->getFilename()}"] = '/var/www/html/wp-content/mu-plugins/' . $mu_plugin->getFilename();
	}
}

// Required envs
$qit_env_id  = $env['QIT_ENV_ID'];
$php_version = $env['PHP_VERSION'] ?? '7.4';
$volumes     = array_merge( json_decode( $env['VOLUMES'] ?? '', true ) ?? [], $default_volumes );
$with_nginx  = $env['QIT_DOCKER_NGINX'] ?? 'yes';
$with_cache  = $env['QIT_DOCKER_REDIS'] ?? 'no';

$volumes_yml = '';

foreach ( $volumes as $local => &$in_container ) {
	// Transform relative local paths into absolute paths.
	if ( substr( $local, 0, 1 ) !== '/' ) {
		$local_path = __DIR__ . '/' . ltrim( $local, '/' );
	} else {
		$local_path = $local;
	}

	/*
	 * Pre-create directories so that permissions are mapped correctly in Docker.
	 */
	if ( ! file_exists( $local_path ) ) {
		exec( "mkdir -p $local_path" );
		if ( file_exists( $local_path ) ) {
			echo "Created directory $local_path\n";
		} else {
			echo "Failed to create directory $local_path\n";
		}
	}

	/*
 * Pre-create volume directories so that permissions are mapped correctly in Docker.
 */
	if ( stripos( $in_container, '/var/www/html/' ) !== false ) {
		// Eg: [ 'wp-content', 'mu-plugins', 'foo.txt' ]
		$parts = explode( '/', str_replace( '/var/www/html/', '', $in_container ) );

		$path_accumulator = __DIR__ . "/html";

		foreach ( $parts as $p ) {
			if ( stripos( $p, '.' ) === false ) {
				$path_accumulator .= "/$p"; // Append the current part to the path accumulator.

				if ( file_exists( $path_accumulator ) ) {
					echo "Skipping directory that already exists $p\n";
					continue;
				}

				exec( "mkdir -p $path_accumulator" );

				if ( file_exists( $path_accumulator ) ) {
					echo "Created directory $path_accumulator\n";
				} else {
					echo "Failed to create directory $path_accumulator\n";
				}
			} else {
				echo "Skipping file $p\n";
			}
		}
	}

	// Make sure all $in_container relative paths are mapped with the same paths as in host.
	if ( substr( $in_container, 0, 1 ) !== '/' ) {
		$in_container = __DIR__ . ltrim( $in_container, '/' );
	}

	// Create the volumes string, following YAML indentation.
	$volumes_yml .= "      - $local_path:$in_container\n";
}

$volumes_yml = rtrim( $volumes_yml );

$docker_images = [
	'db'      => 'jbergstroem/mariadb-alpine:10.6.12',
	'php_fpm' => "automattic/qit-runner-php-$php_version-fpm-alpine:latest",
	'nginx'   => 'nginx:stable-alpine3.17-slim',
	'cache'   => 'redis:6.2.11-alpine',
];

$current_file = __FILE__;

$header = <<<YML
##
## This file is generated from $current_file and it's meant to be used on a disposable CI environment.
##
version: '3.8'
YML;

$database_service = <<<YML
  qit_env_db_$qit_env_id:
    image: {$docker_images['db']}
    container_name: qit_env_db_$qit_env_id
    command:
      --max_allowed_packet=128000000
      --innodb_log_file_size=128000000 
    environment:
      - MYSQL_DATABASE=wordpress
      - MYSQL_USER=admin
      - MYSQL_PASSWORD=password
      - MYSQL_ROOT_PASSWORD=password
    healthcheck:
      test: "mariadb --host=qit_env_db_$qit_env_id --user=root --password=password wordpress --execute 'SELECT 1'"
      interval: 2s
      retries: 10
YML;

$php_fpm_service = <<<YML
  qit_env_php_$qit_env_id:
    image: {$docker_images['php_fpm']} 
    container_name: qit_env_php_$qit_env_id
    user: \${FIXUID:-1000}:\${FIXGID:-1000}
    environment:
      - WP_CLI_CACHE_DIR=/qit/cache/wp-cli
    depends_on:
      qit_env_db_$qit_env_id:
        condition: service_healthy
    volumes:
$volumes_yml
    extra_hosts:
      - "host.docker.internal:host-gateway"
      - "qit.test:host-gateway"
YML;

$dir = __DIR__;

$nginx_service = <<<YML
  qit_env_nginx_$qit_env_id:
    image: {$docker_images['nginx']}
    container_name: qit_env_nginx_$qit_env_id
    depends_on:
      - qit_env_php_$qit_env_id
    restart: on-failure:1
    ports:
      - "80"
    volumes:
      - $dir/docker/nginx/conf.d:/etc/nginx/conf.d
$volumes_yml
YML;

$cache_service = <<<YML
  qit_env_cache_$qit_env_id:
    image: {$docker_images['cache']}
    container_name: qit_env_cache_$qit_env_id
    ports:
      - '6379'
YML;


$docker_compose = <<<DOCKER_COMPOSE
$header

services:
$database_service
$php_fpm_service
DOCKER_COMPOSE;

if ( $with_nginx ) {
	$docker_compose .= "\n$nginx_service";
}

if ( $with_cache ) {
	$docker_compose .= "\n$cache_service";
}

file_put_contents( __DIR__ . '/docker-compose.yml', $docker_compose );
file_put_contents( __DIR__ . '/html/phpinfo.php', <<<'PHP'
<?php
echo "\nget_loaded_extensions():\n";
$loaded_extensions = get_loaded_extensions();
sort($loaded_extensions); 
echo json_encode( $loaded_extensions, JSON_PRETTY_PRINT ) . "\n";

$expected_extensions = json_decode($_GET['php_extensions']);

echo "Expecting extensions: {$_GET['php_extensions']} \n";

foreach ($expected_extensions as $ext) {
	if (!in_array($ext, $loaded_extensions)) {
		echo "\nERROR: $ext is not loaded\n";
		exit(1);
	} else {
		echo "\nOK: $ext is loaded\n";
	}
}
PHP
);