<?php
/**
 * This file lacks the required header.
 * Description: An invalid fixture for testing
 * Version: 1.0.0
 */

// This is not a valid WordPress extension
function invalid_function() {
    echo "This is missing the required header";
}
